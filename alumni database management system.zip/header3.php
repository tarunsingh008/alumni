<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
	    <li><a href="first.php">Back To Home Page</a></li>
      
      </ul>
    </div>
  </div>
</nav>