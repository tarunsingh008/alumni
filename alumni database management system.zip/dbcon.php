<?php
  
	$con= mysqli_connect('localhost', 'root','','alumni database management system');
	if($con==false)
	{
		echo "Connection not done";
	}
	else
	{
		echo"";
	}

?>