<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container">
    <div class="navbar-header">
    	<h3>Welcome to Admin Dashboard</h3>
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
      <li><a href="admindash.php">Back To Dashboard</a></li>
      <li><a href="logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
<div style="margin-bottom: 100px"></div>