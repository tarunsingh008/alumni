<?php
include('header.php');
include('titlehead1.php');
?>

<html>
<head >

<style>
.hero{
	background-image: url("https://images.pexels.com/photos/255379/pexels-photo-255379.jpeg?cs=srgb&dl=abstract-background-blur-255379.jpg&fm=jpg");
	height:400px;
	width:1375px;
	background-position:center;
	background-color:#cccccc;
	position:relative;
	background-size:cover;
	background-repeat:no-repeat;
}
.button {

 display: inline-block;
  padding: 15px 25px;
  font-size: 24px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: #fff;
  background-color: #4CAF50;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
}
.wrapper {
    text-align: center;
}



	
</style>	
</head>
<body >

<div class="hero">
<a href="https://sdmcet.ac.in/">
<h1>
<p style="text-align:center;"><b>WELCOME TO SDMCET</p><br>
<br>

<p style="text-align:center;"> <a href='addalumni.php'>CLICK HERE TO ADD DETAILS</a></p>
</h1>
</a>
</div>
<br>
<h3>
<p  style="text-align:center;"><b>Please give your valuable feedback.</b></p> </h3>
<br>
<div class="wrapper">

<a href="php-email-form/formpage.html"  class="button">FEEDBACK</a><br><br><br>
<h4 style="color:red"><b>NOTE: </b>Please use desktop  site in case of any difficuly.</h4>
</div>
</body>

</html>